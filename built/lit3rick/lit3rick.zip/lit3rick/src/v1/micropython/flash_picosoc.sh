# load fpga bitstream
../../lit3prog/lit3prog -f < picosoc.bin
