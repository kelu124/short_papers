./creset.sh
lit3prog -p < picosoc.bin
./creset.sh

