./build.sh
pip3 uninstall pyusbus -y
python3 setup.py install --user
