rm -rf work *.wlf *.ini transcript
