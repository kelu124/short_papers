gpio mode 6 OUT
gpio write 6 1 
gpio mode 25 IN
gpio mode 2 IN
gpio mode 3 IN
gpio mode 24 IN
gpio mode 10 IN 
gpio mode 11 IN
gpio mode 12 alt0 
gpio mode 13 alt0 
gpio mode 14 alt0 
gpio mode 15 alt0 
gpio mode 16 alt0 

