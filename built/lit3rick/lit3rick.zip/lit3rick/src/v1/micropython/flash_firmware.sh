# load cpu firmware
../../lit3prog/lit3prog -f -O 16 < firmware.bin