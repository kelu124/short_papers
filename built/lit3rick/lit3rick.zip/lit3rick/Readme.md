# lit3rick 

Tentative DOI: 10.5281/zenodo.5792245
